<?php 
/* Redefine the header image width and height ********************************************/
define( 'HEADER_IMAGE_WIDTH', apply_filters( 'twentyten_header_image_width', 900 ) );
define( 'HEADER_IMAGE_HEIGHT', apply_filters( 'twentyten_header_image_height', 407 ) );

// Remove a barra de atualiza��o do Admin
add_filter( 'pre_site_transient_update_core', create_function( '$a', "return null;" ) );

?>